<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return "Laravel 10 Sanctum API Auth";
});
