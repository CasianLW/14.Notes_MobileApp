# Laravel 10 Sanctum Auth

> For demonstration purpose only

Authentication API using Laravel 10 Sanctum (register, login, logout) and abilities.
