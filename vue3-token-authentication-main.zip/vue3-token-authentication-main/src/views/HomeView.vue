<template>
  <main>
    <h1>Home</h1>

    <p>Welcome to Vue 3 Token authentication example.</p>
  </main>
</template>